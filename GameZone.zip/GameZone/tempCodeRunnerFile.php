<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gamezonedb";
$conn = "";

try {
    $conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);
} catch (mysqli_sql_exception $e) {
    echo "Unable to connect: " . $e->getMessage();
}

if ($conn) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST["name"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        
        $insert_query = "INSERT INTO users (username, irl_name, pd, email, Phone) 
                         VALUES ('$username', '$name', '$password', '$email', '$phone')";
        
        if (mysqli_query($conn, $insert_query)) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
        }
    }
}
?>